import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ADBScriptHelper {

    public static String executeCommand(String command) {
        StringBuilder output = new StringBuilder();
        try {
            Process process = Runtime.getRuntime().exec(command);
            process.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line + "\n");

            }
        } catch (Exception e) {
            e.printStackTrace();

        }
        return output.toString();
    }
}
