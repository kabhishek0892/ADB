import org.testng.annotations.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ADBHelper {
    static String device;
    private static String fetchDevice = "adb devices";
    private static String fetchPackage = "adb shell pm list packages -f";
    private static String installApplication = "adb install" + "$path to APK file";
    private static String unInstallApplication = "adb unistall" + "$packageName";
    private static String openAPP = "adb shell am start -n";
    private static String takeScreenShot = "adb exec-out screencap -p >";
    private static String recordScreen = "adb shell screenrecord --verbose --time-limit 30/sdcard/adbmonkey.mp4";
    private static String restartADBServer = "adb kill -server && adb start -server";
    private static String getAndroidVersion = "adb shell getprop ro.build.version.release";
    private static String clearCurrentLog = "adb logcat -c ";
    private static String saveLogCatOpToFile = "adb logcat -d > [path_to_file]";
    private static String bugReport = "adb bugreport > ";
    private static String killDevice = "adb -s " + device + " emu kill";
    private static String clearApplicationData = "adb shell pm clear " + "$packageName";
    private static String MonkeyCommand = "adb shell monkey";
    private static String logCrash = "adb logcat -b crash";
    private static String showAlladbLogs = "adb logcat";
    String result;
    ADBHelper helper;

    int touch = 100, motion = 0, trackball = 0, appswitch = 0, syskeys = 0, anyevent = 0, nav = 0, majornav = 0;


    public String checkIsDeviceConnected() {

        String getdevices = ADBScriptHelper.executeCommand(fetchDevice);
        String[] sarray = getdevices.split("\\n");
        if (sarray.length == 1)
            return "No devices connected";
        else
            device = sarray[1].substring(0, sarray[1].indexOf("d")).trim();
        return device;
    }

    public String selectApp(String appName) {
        if (appName.equalsIgnoreCase("MMT")) return "com.makemytrip";
        else if (appName.equalsIgnoreCase("GI")) return "com.goibibo";
        return "App not found";
    }

    public void installApp(String appName) {
        ADBScriptHelper.executeCommand(installApplication + appName);
    }

    public String appEventPercentage(int appEventPercent) {

        String op = "--pct-touch " + touch + " --pct-motion " + motion + " --pct-trackball " + trackball +
                " --pct-appswitch " + appswitch + " --pct-syskeys " + syskeys + " --pct-anyevent " + anyevent + " --pct-nav " + nav + " --pct-majornav " + majornav;
        System.out.println("Final App event command is " + op);
        return op;
    }

    public String systemEventPercentage(int sysEventPercent) {
        syskeys = 100;
        String op = " --pct-syskeys " + syskeys + " --pct-anyevent " + anyevent + " --pct-nav " + nav + " --pct-majornav " + majornav;
        return op;
    }

    public String verbose() {
        //    String op=" --pct-syskeys "+syskeys+" --pct-anyevent "+anyevent+" --pct-nav "+nav+" --pct-majornav "+majornav;
        return "";
    }

    public String getGetAndroidVersion() {
        String version = ADBScriptHelper.executeCommand(getAndroidVersion);
        return version;
    }

    public int getEventCount(int eventCount) {
        return 1000;
    }

    public String ADBMonkeyCmd(String appName, int events) {
        String finalMonkeyCmd = MonkeyCommand + " -p " + selectApp(appName) + " -v " + events + systemEventPercentage(100);
        System.out.println("Performing monkey testing with command " + finalMonkeyCmd);
        return finalMonkeyCmd;
    }

    public void saveScreenShot() {
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        // ADBScriptHelper.executeCommand("adb exec-out screencap -p >"+"src/test/MonkeyReport/"+"MonkeyReport"+dateFormat.format(date)+".adbimage.png");
        //ScriptHelper.executeCommand("adb exec-out screencap -p >src/test/MonkeyReport/MonkeyReport2022-09-20.adbimage.png");
        System.out.println("adb exec-out screencap -p >" + "src/test/MonkeyReport/" + "MonkeyReport" + dateFormat.format(date) + ".adbimage.png");
    }

    public void recordScreen() {
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("HH-mm-ss");
        String filename = "monkeytest" + dateFormat.format(date);
        ADBScriptHelper.executeCommand("adb shell screenrecord --time-limit 5 /sdcard/" + filename + ".mp4");
        ADBScriptHelper.executeCommand("adb pull /sdcard/" + filename + ".mp4");
        ADBScriptHelper.executeCommand("adb shell rm /sdcard/" + filename + ".mp4");
    }

    @Parameters({"app-Name", "events"})
    @Test
    void MonkeyTest(String app, String event) {
        helper = new ADBHelper();
        result = ADBScriptHelper.executeCommand(helper.ADBMonkeyCmd(app, Integer.parseInt(event)));
    }

    @AfterTest
    public void reporting() throws IOException {
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        File file = new File("src/test/MonkeyReport/" + "MonkeyReport" + dateFormat.format(date) + ".txt");
        BufferedWriter out = new BufferedWriter(new FileWriter(file));
        out.write(result);
        out.close();
        recordScreen();
    }
}
